<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Responsive Portfolio Website</title>

    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=
                Poppins:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
</head>

<body>
    <!-- header design -->
    <header clsss="sticky">
        <a href="#" class="logo">Cod<span>e</span>r.</a>
        <ul class="navlist">
            <li><a href="#home" class="active">Home</a></li>
            <li><a href="#about">About</a></li>
            <li><a href="#services">Services</a></li>
            <li><a href="#portfolio">Portfolio</a></li>
            <li><a href="#contact">Contact</a></li>
        </ul>

        <div class="bx bx-menu" id="menu-icon">


        </div>
    </header>


    <!--home design-->
    <section class="home" id="home">
        <div class="home-text">
            <div class="slide">
                <span class="one">Hello</span>
                <span class="two">I'm</span>
            </div>
            <h1>Tilak</h1>
            <h3>Website/Graphics<span> Designer.</span></h3>
            <p>Web Developer with 2 years experience that keep customers<br>
                comming back for about services makes best effort.</p>
            <div class="button">
                <a href="#" class="btn">Say Hello</a>
                <a href="tech.mp4" class="btn2"><span><i class='bx bx-play'></i></span>Watch My Work</a>
            </div>
        </div>

    </section>
    <div class="underline"></div>



    <!--about section design-->
    <section class="about" id="about">
        <div class="about-img">
            <img src="pp2.png">
        </div>
        <div class="about-text">
            <h2>About <span>Me</span></h2>
            <h4>Creative UI Web Desiner !</h4>
            <p>
                Check out 10 Best Design's updates for the top
                web design & development companies for your needs by reviewing
                list & development companies ! Find the best web design.
                Web Design Consulting. Comprehensive Directory. Top Reviewed Design Firms.
                types: Enterprise Design Firms, Startup Design Firms, Custom Design Firms,
                E-Commerce Design Firms, App Design Firms. Custom Web Solution. 24x7 Customer
                Support Secure Payment Gatway. Get A Free Web Quote. 24/7 Chat Support.
                Services: Web Page Design, Landing Page Design, App Development, Mobile Website Design
            </p>
            <a href="#" class="btn">More About</a>
        </div>
    </section>

    <!--Service Section Design-->
    <section class="#services" id="services">
        <div class="main-text">
            <p>What I am Expert In</p>
            <h2><span>My</span>Services</h2>
        </div>
        <div class="services-content">
            <div class="box">
                <div class="s-icons">
                    <i class="bx bx-mobile-alt"></i>
                </div>
                <h3>Web Design</h3>
                <p> One way to cateforize the activities
                    is in terms of the professional's area
                    of expertise such as competitive analysis,
                    corporate strategy.
                </p>
                <a href="#" class="read">Read More</a>
            </div>


            <div class="box">
                <div class="s-icons">
                    <i class="bx bx-edit-alt"></i>
                </div>
                <h3>Creative Design</h3>
                <p> One way to cateforize the activities
                    is in terms of the professional's area
                    of expertise such as competitive analysis,
                    corporate strategy.
                </p>
                <a href="#" class="read">Read More</a>
            </div>


            <div class="box">
                <div class="s-icons">
                    <i class="bx bx-code-alt"></i>
                </div>
                <h3>Web Development</h3>
                <p> One way to cateforize the activities
                    is in terms of the professional's area
                    of expertise such as competitive analysis,
                    corporate strategy.
                </p>
                <a href="#" class="read">Read More</a>
            </div>
        </div>
    </section>

    <!--Portfolio section design-->
    <section class="portfolio" id="portfolio">
        <div class="main-text">
            <p>Portfolio</p>
            <h2><span>Latest</span>Project</h2>
        </div>
        <div class="portfolio-content">
            <div class="row">
                <img src="project1.png">
                <div class="layer">
                    <h5>Visual Resume Dsign</h5>
                    <p>Check out 10 Best Design's Updates For The Top Web Design & Development Companies</p>
                    <a href="cv/cv.html"><i class='bx bx-link-external'></i></a>
                </div>
            </div>

            <div class="row">
                <img src="project2.png">
                <div class="layer">
                    <h5>Visual Resume Dsign</h5>
                    <p>Check out 10 Best Design's Updates For The Top Web Design & Development Companies</p>
                    <a href="css2/CV.html"><i class='bx bx-link-external'></i></a>


                </div>
            </div>







            <div class="row">
                <img src="project5.jpg" id="p" class="p">
                <div class="layer">
                    <h5>Visual Resume Dsign</h5>
                    <p>Check out 10 Best Design's Updates For The Top Web Design & Development Companies</p>
                    <a href="Resumelast.pdf"><i class='bx bx-link-external'></i></a>
                </div>
            </div>




        </div>

    </section>
    <div class="download">
        <a href="Resume1.pdf" download="resume.pdf"><b>Download PDF</b></a>
    </div>
    <div class="download1">
        <a href="resume2.pdf" download="resume2.pdf"><b>Download PDF</b></a>
    </div>

    <div class="download2">
        <a href="Resumelast.pdf" download="resume3.pdf"><b>Download PDF</b></a>
    </div>

    <!--contact section design-->
    <section class="contact" id="contact">
        <div class="contact-text">
            <h2>Contact<span>Me!</span></h2>
            <h4>If You Have Any Project In Your Mind</h4>
            <p>I'm a UI/Web/Graphic Designer - Creating Bold & Brave Interface Design For Companies All Across The World
            </p>
            <div class="list">
                <li><a href="tel:+9779868165178">9868165178</a></li>
                <li><a href="mailto:tilakp2052@gmail.com">tilakp2052@gmail.com</a></li>
                <li><a href="#">Like Share $ Subscribe</a></li>
            </div>
            <div class="contact-icons">
                <a href="https://www.facebook.com/tilak.paudel.3388"><i class='bx bxl-facebook'></i></a>
                <a href="https://twitter.com/Tilakpa62373839"><i class='bx bxl-twitter'></i></a>
                <a href="https://l.facebook.com/l.php?u=https%3A%2F%2Finstagram.com%2Fck_academy.np%3Figshid%3DZDdkNTZiNTM%253D%26fbclid%3DIwAR3n1KtTapNa5MrogSf_LydepKI3gHxVTfzFaao7GeY0jElMSPDbUsnQdDI&h=AT3RG3oeLASrkTxVLInbDeGcBRxiKUhAP8jpM3TsJyTNCiL3HUZIHWa6Zf8qDuzGWkBRSz7vX4BYiip1LqmvQpRZvWZ_3scssB_Z_73nYneFcxzRASH30Ec6KcoPgMDIVXrUjqzWZUDWOB6mKGts-g"><i class='bx bxl-instagram-alt'></i></a>
                <a href="https://www.youtube.com/channel/UC5QLSCqWRdi7p5arBXIBUbQ"><i class='bx bxl-youtube'></i></a>
            </div>
        </div>
        <!--contact form design-->
        <div class="contact-form">
            <form method="post">
                <input type="name" name="name" placeholder="your name" required>
                <input type="email" name="email" placeholder="your email address" required>
                <input type="" name="phone" placeholder="your mobile number" required>
                <input type="text" height=20 name="text" id="" cols="35" rows="10" placeholder="How can I help you" required></input>
                <input type="submit" name="submit" value="send message" class="submit" required>

            </form>
        </div>
    </section>

    <?php
    if (isset($_POST['submit'])) {
        $n = $_POST['name'];
        $m = $_POST['email'];
        $p = $_POST['phone'];
        $t = $_POST['text'];
        $con = mysqli_connect("localhost", "root", "", "portfolio");
        $sql = "INSERT INTO pmessage(name, email, phone, text) values('$n','$m','$p','$t')";
        if (mysqli_query($con, $sql)) {
            echo " Submit Successfully!! √";
            echo " Admin Will Receive Your Info..😃";
        } else {
            echo "Submit Failed";
        }
    }

    ?>




    <!--end section design-->
    <section class="end">
        <div class="last-text">
            <p> Copyright © 2023 by Tilak Paudel All Rights Reserved.</p>

        </div>
        <div class="top">
            <a href="#home"><i class='bx bx-up-arrow-alt'></i></a>
        </div>
    </section>

    <!--custom js Link--->
    <script type="text/javascript" src="script.js"></script>
</body>

</html>