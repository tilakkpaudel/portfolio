<?php
if(isset($_POST['submit']))
{
    $n=$_POST['name'];
    $m=$_POST['email'];
    $p=$_POST['phone'];
    $t=$_POST['text'];
    $con=mysqli_connect("localhos", "root", "", "portfolio");
    $sql="INSERT INTO pmessage(name, email, phone, text) values('$n','$m','$p','$t')";
    if(mysqli_query($con,$sql))
    {
        echo " Submit Successfully";
    }
    else
    {
        echo "Submit Failed";
    }
}

?>